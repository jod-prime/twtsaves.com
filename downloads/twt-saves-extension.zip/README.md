# TWT Saves – Twitter & X Video Downloader HD (Chrome Extension)

[![Manifest V3](https://img.shields.io/badge/Manifest-V3-blue.svg)](https://developer.chrome.com/docs/extensions/mv3/intro/)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](https://opensource.org/licenses/MIT)
[![Official Website](https://img.shields.io/badge/Official%20Site-twtsaves.com-0284c7.svg)](https://twtsaves.com)

**TWT Saves** is a lightweight, privacy-focused open-source Chrome Extension that adds a native **1-Click Download HD** button directly to every video and animated GIF in your Twitter (X) feed.

Powered by the official [TWT Saves](https://twtsaves.com) high-speed video extraction infrastructure.

---

## 🚀 Key Features

- **⚡ In-Feed 1-Click Download:** Injects a sleek, native-styled `⬇ Download HD` button into the action bar of any tweet containing video or GIF media.
- **🎬 1080p Full HD & Original Bitrate:** Extracts highest resolution MP4 video streams directly from Twitter CDNs with 100% audio sync and zero re-compression.
- **🔄 Universal MP4 Container:** Saves video and looping GIFs in universal H.264 MP4 format compatible with iPhone, Android, Mac, Windows, and video editing suites.
- **🖱️ Right-Click Context Menu:** Right-click any tweet link anywhere on the web and select *"Download Video with TWT Saves"*.
- **📱 Smart Popup:** Automatically detects if your active tab is currently viewing a tweet, providing 1-click video saving without copying or pasting links.
- **🔒 100% Private & Ad-Free:** Zero telemetry, no user tracking, no cookies, and no registration required.

---

## 🛠️ Free Web Tools & Ecosystem

If you are on mobile or do not wish to install a browser extension, access our suite of free online tools directly:

- **Official Web Downloader:** [https://twtsaves.com](https://twtsaves.com)
- **Twitter to MP4 Converter:** [https://twtsaves.com/twitter-to-mp4](https://twtsaves.com/twitter-to-mp4)
- **Twitter to MP3 Audio Downloader:** [https://twtsaves.com/twitter-to-mp3](https://twtsaves.com/twitter-to-mp3)
- **Twitter GIF Downloader:** [https://twtsaves.com/twitter-gif-downloader](https://twtsaves.com/twitter-gif-downloader)
- **X.com Video Downloader:** [https://twtsaves.com/x-video-downloader](https://twtsaves.com/x-video-downloader)
- **Apple iOS Siri Shortcut:** [https://twtsaves.com/shortcuts](https://twtsaves.com/shortcuts)

---

## 📦 How to Install (Developer Mode)

1. Clone or download this repository:
   ```bash
   git clone https://github.com/Prithiraj007/TWITTER_X.git
   ```
2. Open Google Chrome, Brave, Edge, or any Chromium-based browser and navigate to:
   ```
   chrome://extensions/
   ```
3. Enable **Developer mode** in the top-right corner.
4. Click **Load unpacked** in the top-left corner.
5. Select the `chrome-extension/` directory.
6. Open [x.com](https://x.com) or [twitter.com](https://twitter.com) — you will now see the `⬇ Download HD` button under every video tweet!

---

## 📝 Chrome Web Store Review Justification

For publishing to the Chrome Web Store:

- **Single Purpose:** This extension allows users to easily download public multimedia files from Twitter/X.
- **Permission Justification (`activeTab`):** Used solely to inspect whether the currently active tab is an X/Twitter post to offer instant 1-click download in the popup.
- **Permission Justification (`contextMenus`):** Adds a convenient right-click option to download videos directly from tweet links.
- **Privacy Policy:** [https://twtsaves.com/privacy](https://twtsaves.com/privacy)

---

## 📄 License

This project is licensed under the MIT License — see the [LICENSE](LICENSE) file for details.
