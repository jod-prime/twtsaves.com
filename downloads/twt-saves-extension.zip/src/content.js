/**
 * TWT Saves – Twitter & X Video Downloader Content Script
 * Automatically injects a "⬇ Download" button into Twitter/X feed tweets containing videos.
 */

(function () {
  'use strict';

  // Prevent multiple injections in same frame
  if (window.__TWT_SAVES_INJECTED__) return;
  window.__TWT_SAVES_INJECTED__ = true;

  const TWT_SITE_URL = 'https://twtsaves.com';

  function cleanTweetUrl(rawUrl) {
    if (!rawUrl) return null;
    try {
      const parsed = new URL(rawUrl.startsWith('http') ? rawUrl : `https://x.com${rawUrl}`);
      const match = parsed.pathname.match(/\/(?:status|statuses)\/(\d+)/i);
      if (match) {
        return `https://x.com/i/status/${match[1]}`;
      }
      return parsed.origin + parsed.pathname;
    } catch {
      return rawUrl;
    }
  }

  function createDownloadButton(tweetUrl) {
    const btn = document.createElement('div');
    btn.className = 'twt-download-btn';
    btn.setAttribute('role', 'button');
    btn.setAttribute('tabindex', '0');
    btn.setAttribute('title', 'Download HD Video with TWT Saves');
    btn.setAttribute('aria-label', 'Download Video with TWT Saves');

    btn.innerHTML = `
      <div class="twt-download-btn-inner">
        <svg viewBox="0 0 24 24" class="twt-download-icon" aria-hidden="true">
          <path fill="currentColor" d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 14l-4-4 1.41-1.41L11 13.17V7h2v6.17l2.59-2.58L17 12l-6 4z"/>
        </svg>
        <span class="twt-download-label">Download HD</span>
      </div>
    `;

    const handleTrigger = (e) => {
      e.stopPropagation();
      e.stopImmediatePropagation();
      e.preventDefault();

      let targetUrl = tweetUrl;
      if (!targetUrl || !targetUrl.includes('/status/')) {
        targetUrl = window.location.href;
      }

      const cleaned = cleanTweetUrl(targetUrl);
      const destination = `${TWT_SITE_URL}/?url=${encodeURIComponent(cleaned)}`;
      window.open(destination, '_blank', 'noopener,noreferrer');
    };

    // Use capture: true so Twitter's parent feed click-listener doesn't open the tweet
    btn.addEventListener('click', handleTrigger, true);

    btn.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.stopPropagation();
        e.preventDefault();
        handleTrigger(e);
      }
    });

    return btn;
  }

  function extractTweetUrl(article) {
    // 1. Look for status timestamp link inside article
    const timeLink = article.querySelector('a[href*="/status/"] time')?.closest('a');
    if (timeLink && timeLink.getAttribute('href')) {
      return cleanTweetUrl(timeLink.getAttribute('href'));
    }

    // 2. Look for any link containing /status/
    const anyStatusLink = article.querySelector('a[href*="/status/"]');
    if (anyStatusLink && anyStatusLink.getAttribute('href')) {
      return cleanTweetUrl(anyStatusLink.getAttribute('href'));
    }

    // 3. Fallback: if we are viewing the status page directly
    if (window.location.pathname.includes('/status/')) {
      return cleanTweetUrl(window.location.href);
    }

    return null;
  }

  function processTweets() {
    const articles = document.querySelectorAll('article[data-testid="tweet"]');

    articles.forEach((article) => {
      // Don't inject if already has the button
      if (article.querySelector('.twt-download-btn')) {
        article.setAttribute('data-twt-processed', 'true');
        return;
      }

      // Check if this tweet contains video or GIF elements
      const hasVideo =
        article.querySelector('[data-testid="videoPlayer"]') ||
        article.querySelector('[data-testid="videoComponent"]') ||
        article.querySelector('video') ||
        article.querySelector('div[aria-label*="Play"]') ||
        article.querySelector('div[aria-label*="GIF"]') ||
        article.querySelector('[data-testid="playButton"]') ||
        article.querySelector('div[data-testid="tweetPhoto"] video') ||
        article.querySelector('div[data-testid="card.layoutLarge.media"] video');

      if (!hasVideo) return; // Do not mark processed; video player might mount in next tick

      const actionBar = article.querySelector('[role="group"]');
      if (!actionBar || actionBar.querySelector('.twt-download-btn')) return;

      const tweetUrl = extractTweetUrl(article);
      if (!tweetUrl) return;

      const downloadBtn = createDownloadButton(tweetUrl);
      actionBar.appendChild(downloadBtn);
      article.setAttribute('data-twt-processed', 'true');
    });
  }

  // Initial pass
  processTweets();

  // Throttled MutationObserver for continuous feeds
  let throttleTimer = null;
  const observer = new MutationObserver(() => {
    if (throttleTimer) return;
    throttleTimer = setTimeout(() => {
      processTweets();
      throttleTimer = null;
    }, 200);
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true,
  });
})();
