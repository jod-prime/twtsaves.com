/**
 * TWT Saves – Popup Logic
 */

const TWT_SITE_URL = 'https://twtsaves.com';

function cleanTwitterUrl(rawUrl) {
  if (!rawUrl) return '';
  try {
    const parsed = new URL(rawUrl.startsWith('http') ? rawUrl : `https://x.com/${rawUrl}`);
    const match = parsed.pathname.match(/\/(?:status|statuses)\/(\d+)/i);
    if (match) {
      return `https://x.com/i/status/${match[1]}`;
    }
    return rawUrl.trim();
  } catch {
    return (rawUrl || '').trim();
  }
}

document.addEventListener('DOMContentLoaded', async () => {
  const detectedBox = document.getElementById('detected-box');
  const detectedUrlEl = document.getElementById('detected-url');
  const btnDownloadCurrent = document.getElementById('btn-download-current');
  const urlInput = document.getElementById('url-input');
  const btnDownloadInput = document.getElementById('btn-download-input');
  const errorMsg = document.getElementById('error-msg');

  let currentTabUrl = '';

  // 1. Check if the active tab is an X / Twitter post
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab && tab.url) {
      const isTwitter =
        tab.url.includes('twitter.com') ||
        tab.url.includes('x.com');
      const hasStatus = tab.url.includes('/status/');

      if (isTwitter && hasStatus) {
        currentTabUrl = cleanTwitterUrl(tab.url);
        detectedUrlEl.textContent = currentTabUrl;
        detectedBox.classList.remove('hidden');
      } else {
        urlInput?.focus();
      }
    } else {
      urlInput?.focus();
    }
  } catch (err) {
    console.error('Error querying active tab:', err);
    urlInput?.focus();
  }

  // 2. Download from current tab
  if (btnDownloadCurrent) {
    btnDownloadCurrent.addEventListener('click', () => {
      if (!currentTabUrl) return;
      const destination = `${TWT_SITE_URL}/?url=${encodeURIComponent(currentTabUrl)}`;
      chrome.tabs.create({ url: destination });
      window.close();
    });
  }

  // 3. Download from manual URL input
  function triggerDownloadInput() {
    const raw = (urlInput.value || '').trim();
    if (!raw) {
      showError('Please paste a tweet URL first.');
      return;
    }

    const isValid =
      (raw.includes('twitter.com') || raw.includes('x.com')) &&
      (raw.includes('/status/') || raw.includes('/statuses/'));

    if (!isValid) {
      showError('Please enter a valid Twitter/X post link.');
      return;
    }

    hideError();
    const cleaned = cleanTwitterUrl(raw);
    const destination = `${TWT_SITE_URL}/?url=${encodeURIComponent(cleaned)}`;
    chrome.tabs.create({ url: destination });
    window.close();
  }

  btnDownloadInput.addEventListener('click', triggerDownloadInput);

  urlInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      triggerDownloadInput();
    }
  });

  // 4. Handle external links reliably
  document.querySelectorAll('a[href^="http"]').forEach((link) => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      chrome.tabs.create({ url: link.href });
    });
  });

  function showError(msg) {
    errorMsg.textContent = msg;
    errorMsg.classList.remove('hidden');
  }

  function hideError() {
    errorMsg.textContent = '';
    errorMsg.classList.add('hidden');
  }
});
