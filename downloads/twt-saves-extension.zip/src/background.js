/**
 * TWT Saves – Background Service Worker (Manifest V3)
 */

const TWT_SITE_URL = 'https://twtsaves.com';

function cleanTwitterUrl(rawUrl) {
  if (!rawUrl) return '';
  try {
    const parsed = new URL(rawUrl);
    const match = parsed.pathname.match(/\/(?:status|statuses)\/(\d+)/i);
    if (match) {
      return `https://x.com/i/status/${match[1]}`;
    }
    return rawUrl;
  } catch {
    return rawUrl;
  }
}

// Setup Context Menus on Installation/Update cleanly
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: 'twt-download-context',
      title: 'Download Video with TWT Saves',
      contexts: ['link', 'page'],
      targetUrlPatterns: ['*://*.twitter.com/*', '*://*.x.com/*'],
    });
  });
});

// Handle Context Menu Clicks
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === 'twt-download-context') {
    const rawTarget = info.linkUrl || info.pageUrl;
    if (rawTarget) {
      const cleaned = cleanTwitterUrl(rawTarget);
      const destination = `${TWT_SITE_URL}/?url=${encodeURIComponent(cleaned)}`;
      chrome.tabs.create({ url: destination });
    }
  }
});

// Message Listener for Content Scripts
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'openDownload' && request.url) {
    const cleaned = cleanTwitterUrl(request.url);
    const destination = `${TWT_SITE_URL}/?url=${encodeURIComponent(cleaned)}`;
    chrome.tabs.create({ url: destination });
    sendResponse({ success: true, destination });
  }
  return true;
});

